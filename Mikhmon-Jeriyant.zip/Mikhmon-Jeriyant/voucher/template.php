																								
<?php
if (substr($validity, -1) == "d") {
    $validity = "<br>Masa Aktif : " . substr($validity, 0, -1) . " Hari";
} elseif (substr($validity, -1) == "h") {
    $validity = "Masa Aktif : " . substr($validity, 0, -1) . " Jam";
}
if ((substr($timelimit, -1) == "d") & (strlen($timelimit) > 3)) {
    $timelimit =
        "Durasi : " .
        (substr($timelimit, 0, -1) * 7 + substr($timelimit, 2, 1)) .
        " Hari";
} elseif (substr($timelimit, -1) == "d") {
    $timelimit = "Durasi : " . substr($timelimit, 0, -1) . " Hari";
} elseif (substr($timelimit, -1) == "h") {
    $timelimit = "Durasi : " . substr($timelimit, 0, -1) . " Jam";
} elseif (substr($timelimit, -1) == "w") {
    $timelimit = "Durasi : " . substr($timelimit, 0, -1) * 7 . " Hari";
}

/* Setting Warna Voucher Disini */
if ($getprice == "2000") {
    $color = "#00A300";
} elseif ($getprice == "3000") {
    $color = "#00A300";
} elseif ($getprice == "5000") {
    $color = "#000000";
} elseif ($getprice == "8000") {
    $color = "#000000";
} elseif ($getprice == "10000") {
    $color = "#000CFF";
} elseif ($getprice == "13000") {
    $color = "#000CFF";
} elseif ($getprice == "15000") {
    $color = "#000CFF";
} elseif ($getprice == "20000") {
    $color = "#FF0000";
} elseif ($getprice == "23000") {
    $color = "#FF0000";
} elseif ($getprice == "25000") {
    $color = "#FF0000";
} elseif ($getprice == "50000") {
    $color = "#FF33A5";
} elseif ($getprice == "65000") {
    $color = "#FF33A5";
} elseif ($getprice == "100000") {
    $color = "#ff7b00";
} else {
    $color = "#FF69B4";
}
?>
<table style="display: inline-block;border-collapse: collapse;border: 1px solid #666;margin: 2.5px;width: 190px;overflow:hidden;position:relative;padding: 1px;margin: 0px;border: 1px solid #444; background:; ">
<tbody>
<tr>

<!-- Setting Judul Voucher Disini -->
<td style="background:<?php echo $color; ?>;color:#666;padding:0px;" valign="top" colspan="2">
<div style="text-align:center;color:#fff;font-size:12px;font-weight:bold;margin:1px;padding:2.5px;">
 <b><?= $hotspotname; ?></b>	
</div>
</td>		
<tr>
<td style="color:#666;" valign="top">
<table style="width:100%;">
<tbody>
<tr>	
<tr>
<td style="width:75px">
<div style="position:relative;z-index:-1;padding: 0px;float:left;">
<div style="position:absolute;top:0;display:inline;margin-top:-100px;width: 0; height: 0; border-top: 230px solid transparent;border-left: 50px solid transparent;border-right:140px solid #DCDCDC; "></div>	
</div>	
</div>


<!-- Logo Voucher Disini -->
<img style="margin:-2px 0 0 5px;" width="70" height="28" src="<?php echo $logo; ?>" alt="logo">	
</td>	
<td style="width:115px">
<div style="float:right;margin-top:-6px;margin-right:0px;width:5%;text-align:right;font-size:7px;">
</div>


<!-- Tulisan Harga Voucher Disini -->
<div style="margin:-10px;text-align:right;font-weight:bold;font-size:16px;padding-left:17px;color:<?php echo $color; ?>"> <?= $price ?>
</div>	
</td>		
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="color:#666;border-collapse: collapse;" valign="top">
<table style="width:100%;border-collapse: collapse;">
<tbody>
<tr>
<td style="width:95px"valign="top" >
<div style="clear:both;color:#555;margin-top:5px;margin-bottom:2.5px;">
<?php if ($usermode == "vc") { ?> 
<div style="padding:0px;border-bottom:1px solid;text-align:center;font-weight:bold;font-size:12px;color:#444">Kode Voucher</div>		
<div style="padding:0px;border-bottom:1px solid;text-align:center;font-weight:bold;font-size:14px;color:<?php echo $color; ?>"><?php echo $username; ?></div>
<?php } elseif ($usermode == "up") { ?>
<div style="padding:0px;border-bottom:1px solid;text-align:center;font-weight:bold;font-size:12px;color:#444">Account Member</div>		
<div style="padding:0px;border-bottom:1px solid;text-align:center;font-weight:bold;font-size:12px;color:<?php echo $color; ?>">
<?php echo "Username: " . $username . "<br>Password: " . $password; ?></div>
<?php } ?>


<!--Tulisan Pesan Disini-->
</div>
<div style="text-align:center;color:#111;font-size:9px;font-weight:bold;margin:0px;padding:2.5px;">
<i>Login Voucher Buka Browser/Chrome Masuk Ke <b><?= $dnsname; ?></b></i>
</div>	
</td>	
<p style=" margin-top:-10px;margin-bottom:0px">		
<td style="width:100px;text-align:right;">


<!-- Tulisan Harga dan Kuota Disini -->
<div style="clear:both;padding:0 1px;font-size:7px;font-weight:bold;color:#000000">
<?php echo $validity; ?><br> <?php echo $timelimit; ?> <br>Kuota : <?php echo $datalimit; ?>
</div>


<!-- QR Code Disini -->
<img style="solid;float:right;padding:1px;text-align:right;width:80%;margin:0 1px -5px 0;"><img style="border: 1px <?php echo $color; ?> solid; border-radius: 2px; solid  #444;width:60px;height:60px;"  <?= $qrcode ?></div>
</td>		
</tr>
<tr>

<!-- Tulisan Komentar Disini -->
<td style="background:<?php echo $color; ?>;color:#666;padding:0px;" valign="top" colspan="2">
<div style="text-align:left;color:#fff;font-size:11px;font-weight:bold;margin:0px;padding:2.5px;">
<b><?= $comment ?></b>
<span id="num"><?= " [$num]" ?>
</div>
</td>	
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
 <!--Directed by Jeriyant - Baramcity-->	        	        	        	        	        	        	        	        	        	        	        	        	        	        	        